<div class="panel panel-default" style="margin-top: 40px">
    <div class="panel-heading">
        <h3 class="panel-title">Application Sections</h3>
    </div>

    <div class="list-group">
        <!--new_app-->
        <a href="app_pg_1.php" class="list-group-item" id="link_new_app">New Application</a>

        <!--pers_info-->
        <a href="app_pg_2.php" class="list-group-item" id="link_pers_info">Personal Information</a>

        <!--app_info-->
        <a href="app_pg_3.php" class="list-group-item" id="link_app_info">Application Information</a>

        <!--educ_hist-->
        <a href="#" class="list-group-item" id="link_educ_hist">Educational History</a>

        <!--empl_hist-->
        <a href="#" class="list-group-item" id="link_empl_hist">Employment History</a>

        <!--entr_test-->
        <a href="#" class="list-group-item" id="link_entr_test">Entrance Tests</a>

    </div>
</div>
