<!--navbar and branding-->

<div class="content row">
    <div class="col-lg-12">

        <section id="branding">
            <h1>SEATTLE UNIVERSITY</h1>
        </section><!-- branding -->

        <section id="navbar">
            <ul class="nav nav-tabs">
                <li role="presentation" class="disabled"><a href="#">Home</a></li>
                <li role="presentation" class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Academics <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a tabindex="-1" href="#" class="disabled">College of Arts & Sciences</a></li>
                            <li><a tabindex="-1" href="#" class="disabled">College of Engineering</a></li>
                        </ul>
                </li>
                <li role="presentation" class="active"><a href="#">Student Application</a></li>
            </ul>
        </section><!-- navbar -->

    </div>
</div>
